package inicio;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

public class Main {


	@SuppressWarnings("unchecked")
	public static void main(String[] args) {

	 
	
		Session s = HibernateUtil.crearSesion();
		s.getTransaction().begin();
		System.out.println("\n 1.- Mostrar el nombre del producto y el nombre de la categor�a de "
				+ "todos los productos que contengan la letra Q en el nombre. \n");
		Query query = s.createQuery(
				"SELECT prod.producto, cat.categoria "
				+"FROM Productos prod, Categorias cat "
				+"WHERE prod.producto like '%Q%' "
				+"and prod.categorias = cat.id "
				+"order by cat.categoria, prod.producto"
				);
		listaQuery (query);
		
		// consulta 2
		System.out.println("\n 2.- Mostrar el n�mero de pedido y el pa�s del cliente "
				+ "de los pedidos de mayo del a�o 1997 \n");
		query = s.createQuery(
				"SELECT ped.id, ped.fechaPedido, ped.clientes.pais "
				+"FROM Pedidos ped "
				+"WHERE YEAR(ped.fechaPedido) = 1997 "
				+ "and MONTH(ped.fechaPedido) = 5 "
				+ "order by ped.fechaPedido "

				);
		listaQuery (query);
		
		// consulta 3
				System.out.println("\n 3.- Mostrar fecha del pedido, cantidad y el nombre producto, y el c�digo del pedido para  los c�digos de pedido 10285 o 10298.7 \n");
				
				query = s.createQuery(
						"SELECT p.id, p.fechaPedido, d.cantidad, "
						+ "s.producto, d.precioUnidad " + 
						"FROM Pedidos p" + 
						" JOIN p.detalleses d" + 
						"  JOIN d.productos s" + 
						" WHERE p.id = 10285" + 
						"   OR p.id = 10298" + 
						"ORDER BY p.id, p.fechaPedido "
						);
				listaQuery (query);
		
				// consulta 4
				System.out.println(" 4.- �Cu�nto se factura cada mes? Mostrar el a�o, el mes y el total. \n");
				
				query = s.createQuery(
						"SELECT year(p.fechaPedido) , "
						+ " month(p.fechaPedido) , " + 
						"  SUM(d.cantidad *  d.precioUnidad * (1 - d.descuento))  " + 
						"FROM Pedidos p "
						+ " JOIN p.detalleses d " + 
						"GROUP BY 1, 2 " + 
						"ORDER BY 3"
						);
				listaQuery (query);
				
				// consulta 5
				System.out.println("\n 5.- Los pedidos que hizo la empleada Nancy. \n");
				
				query = s.createQuery(
						"Select p.id, p.fechaPedido, e.nombre "
						+ "FROM Pedidos p "
						+ " JOIN p.empleados e " + 
						"WHERE e.nombre='Nancy'"
						);
				listaQuery (query);
				
				// consulta 6
				System.out.println("\n 6.- Mostrar los pedidos de Anton (c�digo cliente) \n");
				
				query = s.createQuery(
						"Select p.id, p.fechaPedido, c.codigo "
						+ "FROM Pedidos p "
						+ " JOIN p.clientes c " + 
						"WHERE c.codigo='ANTON'"
						);
				listaQuery (query);
				
				// consulta 7
				System.out.println("\n 7.- Cu�ntos productos hay de cada categor�a y el precio medio \n");
				
				query = s.createQuery(
						"Select c.categoria, COUNT(p.id), AVG(p.precioUnidad) "
						+ "FROM Categorias c "
						+ "LEFT JOIN c.productoses p " + 
						"GROUP BY c.categoria"
						);
				listaQuery (query);
				
				// consulta 8
				System.out.println("\n 8.- Mostrar los pedidos que tienen productos en la categor�a 2 o 3 \n");
				
				query = s.createQuery(
						"Select DISTINCT de.pedidos.id, de.pedidos.fechaPedido "
						+ "FROM Detalles de "
						+ "WHERE de.productos IN("
						+ 	"SELECT pr.id "
						+ 	"FROM Productos pr"
						+ 	" WHERE pr.categorias IN (2,3)"
						+ ")"
						+ " order by 1"
						);
				listaQuery (query);
				
				// consulta 9
				System.out.println("\n 9.- Clientes que pidieron queso en julio de 1997 \n");
				
				query = s.createQuery(
						"Select DISTINCT c.empresa, pr.producto "
						+ "FROM Clientes c "
						+ "JOIN c.pedidoses p "
						+ "JOIN p.detalleses d "
						+ "JOIN d.productos pr "
 						+ "WHERE p.fechaPedido BETWEEN '1997-07-01' AND '1997-07-31'" 
						+ " AND producto LIKE '%queso%'"
						);
				listaQuery (query);
				
		//cerramos sesion hibernate
	
		System.out.println("fin");
		s.getTransaction().commit();
		HibernateUtil.cerrarSesion();

	}
	
	private static void listaQuery (Query query) {
		// listamos productos
		List<Object[]> consulta = query.list();
		
		for (Object[] ps : consulta) {
			for(int i=0;i<ps.length;i++) {
				System.out.print(ps[i].toString()+"   ");
			}
			System.out.println();
		}
	}
		
	}


